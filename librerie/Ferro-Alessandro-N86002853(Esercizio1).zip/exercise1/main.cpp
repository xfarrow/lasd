#include "container/container.hpp"
#include "vector/vector.hpp"
#include "list/list.hpp"
#include "zlasdtest/test.hpp"

#include "zmytest/test.hpp"

/* ************************************************************************** */

#include <iostream>

/* ************************************************************************** */

int main() {
  std::cout << "Lasd Libraries 2020" << std::endl;
  menu();
  return 0;
}
