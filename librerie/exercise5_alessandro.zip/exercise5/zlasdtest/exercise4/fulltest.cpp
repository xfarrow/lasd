
void testFullExercise4() {
}
